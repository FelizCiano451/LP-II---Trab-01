import ui.MenuCLI;

public class Main {
    public static void main(String[] args) {
        MenuCLI menu = new MenuCLI();
        menu.exibirMenu();
    }
}
