package ui;

import java.util.Scanner;

public class MenuCLI {
    public void exibirMenu() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Bem-vindo ao Gerenciador de Biblioteca PDF!");
        System.out.println("Funcionalidade de menu em desenvolvimento...");
        scanner.close();
    }
}
