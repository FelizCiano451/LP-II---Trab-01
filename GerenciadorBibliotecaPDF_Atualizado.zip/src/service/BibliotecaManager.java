package service;

import model.*;

import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.stream.Collectors;

public class BibliotecaManager {
    private String bibliotecaPath;
    private final List<EntradaPDF> entradas = new ArrayList<>();
    private final PersistenceManager persistenceManager;

    public BibliotecaManager(PersistenceManager persistenceManager) {
        this.persistenceManager = persistenceManager;
        this.bibliotecaPath = persistenceManager.carregarPathBiblioteca();
    }

    public boolean bibliotecaCarregada() {
        return bibliotecaPath != null && Files.exists(Path.of(bibliotecaPath));
    }

    public void criarNovaBiblioteca(String path) {
        this.bibliotecaPath = path;
        new File(path).mkdirs();
        persistenceManager.salvarPathBiblioteca(path);
        entradas.clear();
    }

    public void adicionarEntrada(EntradaPDF entrada) {
        entradas.add(entrada);
        String nomeAutor = entrada.getAutores().get(0).trim().replace(" ", "_");
        Path destino = Path.of(bibliotecaPath, nomeAutor);
        destino.toFile().mkdirs();

        try {
            Path origem = Path.of(entrada.getCaminhoArquivo());
            Files.copy(origem, destino.resolve(origem.getFileName()), StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException e) {
            System.out.println("Erro ao copiar o arquivo PDF.");
        }
    }

    public List<EntradaPDF> listarTodas() {
        return new ArrayList<>(entradas);
    }

    public List<EntradaPDF> buscarPorTitulo(String termo) {
        return entradas.stream()
                .filter(e -> e.getTitulo().toLowerCase().contains(termo.toLowerCase()))
                .collect(Collectors.toList());
    }

    public void deletarEntrada(String titulo) {
        entradas.removeIf(e -> e.getTitulo().equalsIgnoreCase(titulo));
    }

    public void alternarBiblioteca(String path) {
        this.bibliotecaPath = path;
        persistenceManager.salvarPathBiblioteca(path);
        entradas.clear();
    }

    public void deletarBibliotecaAtual() {
        entradas.clear();
    }
}
