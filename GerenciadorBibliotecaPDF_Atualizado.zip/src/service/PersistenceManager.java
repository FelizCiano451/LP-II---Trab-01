package service;

import java.io.*;

public class PersistenceManager {
    private final String pathArquivo = "biblioteca_path.txt";

    public void salvarPathBiblioteca(String path) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(pathArquivo))) {
            writer.write(path);
        } catch (IOException e) {
            System.out.println("Erro ao salvar o caminho da biblioteca.");
        }
    }

    public String carregarPathBiblioteca() {
        try (BufferedReader reader = new BufferedReader(new FileReader(pathArquivo))) {
            return reader.readLine();
        } catch (IOException e) {
            return null;
        }
    }
}
