package ui;

import model.*;
import service.BibliotecaManager;
import service.PersistenceManager;

import java.util.*;

public class MenuCLI {
    private Scanner scanner;
    private BibliotecaManager bibliotecaManager;

    public MenuCLI() {
        scanner = new Scanner(System.in);
        bibliotecaManager = new BibliotecaManager(new PersistenceManager());
    }

    public void exibirMenu() {
        System.out.println("=== GERENCIADOR DE BIBLIOTECA PDF ===");

        if (!bibliotecaManager.bibliotecaCarregada()) {
            System.out.print("Digite o caminho para criar uma nova biblioteca: ");
            String path = scanner.nextLine();
            bibliotecaManager.criarNovaBiblioteca(path);
            System.out.println("Biblioteca criada com sucesso.");
        }

        int opcao = -1;
        do {
            System.out.println("\n[1] Adicionar entrada");
            System.out.println("[2] Listar entradas");
            System.out.println("[3] Buscar entrada por título");
            System.out.println("[4] Editar entrada");
            System.out.println("[5] Deletar entrada");
            System.out.println("[6] Criar nova biblioteca");
            System.out.println("[7] Alternar biblioteca");
            System.out.println("[8] Deletar biblioteca atual");
            System.out.println("[0] Sair");
            System.out.print("Escolha: ");
            opcao = Integer.parseInt(scanner.nextLine());

            switch (opcao) {
                case 1 -> adicionarEntrada();
                case 2 -> listarEntradas();
                case 3 -> buscarEntrada();
                case 4 -> editarEntrada();
                case 5 -> deletarEntrada();
                case 6 -> criarNovaBiblioteca();
                case 7 -> alternarBiblioteca();
                case 8 -> deletarBiblioteca();
                case 0 -> System.out.println("Saindo...");
                default -> System.out.println("Opção inválida!");
            }
        } while (opcao != 0);
    }

    // ... [Funções auxiliares aqui omitidas por brevidade]
}
