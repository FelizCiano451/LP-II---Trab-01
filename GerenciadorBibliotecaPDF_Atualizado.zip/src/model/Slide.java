package model;

import java.util.List;

public class Slide extends EntradaPDF {
    private String disciplina;
    private String instituicao;

    public Slide(String titulo, List<String> autores, String caminhoArquivo, String disciplina, String instituicao) {
        super(titulo, autores, caminhoArquivo);
        this.disciplina = disciplina;
        this.instituicao = instituicao;
    }

    @Override
    public String getTipo() {
        return "Slide";
    }
}
