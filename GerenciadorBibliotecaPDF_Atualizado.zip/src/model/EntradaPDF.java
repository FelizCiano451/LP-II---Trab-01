package model;

import java.util.List;

public abstract class EntradaPDF {
    protected String titulo;
    protected List<String> autores;
    protected String caminhoArquivo;

    public EntradaPDF(String titulo, List<String> autores, String caminhoArquivo) {
        this.titulo = titulo;
        this.autores = autores;
        this.caminhoArquivo = caminhoArquivo;
    }

    public String getTitulo() {
        return titulo;
    }

    public List<String> getAutores() {
        return autores;
    }

    public String getCaminhoArquivo() {
        return caminhoArquivo;
    }

    public abstract String getTipo();
}
