package model;

import java.util.List;

public class Livro extends EntradaPDF {
    private String subtitulo;
    private String areaConhecimento;
    private int anoPublicacao;
    private String editora;
    private int numeroPaginas;

    public Livro(String titulo, List<String> autores, String caminhoArquivo, String subtitulo,
                 String areaConhecimento, int anoPublicacao, String editora, int numeroPaginas) {
        super(titulo, autores, caminhoArquivo);
        this.subtitulo = subtitulo;
        this.areaConhecimento = areaConhecimento;
        this.anoPublicacao = anoPublicacao;
        this.editora = editora;
        this.numeroPaginas = numeroPaginas;
    }

    @Override
    public String getTipo() {
        return "Livro";
    }
}
