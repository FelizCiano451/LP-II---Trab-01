package model;

import java.util.List;

public class NotaDeAula extends EntradaPDF {
    private String subtitulo;
    private String disciplina;
    private String instituicao;
    private int numeroPaginas;

    public NotaDeAula(String titulo, List<String> autores, String caminhoArquivo,
                      String subtitulo, String disciplina, String instituicao, int numeroPaginas) {
        super(titulo, autores, caminhoArquivo);
        this.subtitulo = subtitulo;
        this.disciplina = disciplina;
        this.instituicao = instituicao;
        this.numeroPaginas = numeroPaginas;
    }

    @Override
    public String getTipo() {
        return "NotaDeAula";
    }
}
